//
//  HggManager.h
//  搜索历史记录（此方法用NSUserDefaults）
//
//  Created by 胡高广 on 2017/8/11.
//  Copyright © 2017年 胡高广. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface HggManager : NSObject

//缓存搜索的数组
+(void)SearchText :(NSString *)seaTxt;
//清除缓存的数组
+(void)removeAllArray;

@end
