//
//  AppDelegate.h
//  搜索历史记录（此方法用NSUserDefaults）
//
//  Created by 胡高广 on 2017/8/11.
//  Copyright © 2017年 胡高广. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

