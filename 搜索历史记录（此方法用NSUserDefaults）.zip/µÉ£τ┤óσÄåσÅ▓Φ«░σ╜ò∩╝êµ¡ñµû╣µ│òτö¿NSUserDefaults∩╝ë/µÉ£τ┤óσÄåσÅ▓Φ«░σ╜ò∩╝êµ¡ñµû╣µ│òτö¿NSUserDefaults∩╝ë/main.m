//
//  main.m
//  搜索历史记录（此方法用NSUserDefaults）
//
//  Created by 胡高广 on 2017/8/11.
//  Copyright © 2017年 胡高广. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
